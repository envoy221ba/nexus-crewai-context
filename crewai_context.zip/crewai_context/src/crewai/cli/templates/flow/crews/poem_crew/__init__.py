"""Poem crew template."""
