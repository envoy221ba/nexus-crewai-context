"""OpenAI agent adapters for crewAI."""
